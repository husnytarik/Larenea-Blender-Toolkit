import bpy


class VIEW3D_PT_th_tools(bpy.types.Panel):
    bl_label = "🛠️ Larenea Toolkit"
    bl_idname = "VIEW3D_PT_th_blender_toolkit"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Larenea Toolkit"

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        props = (
            getattr(obj, "mesh_data_transfer_object", None)
            if (obj and obj.type == "MESH")
            else None
        )

        # — Mesh Data Transfer Section —
        md_box = layout.box()
        md_box.label(text="Mesh Data Transfer", icon="MOD_DATA_TRANSFER")

        if not obj or obj.type != "MESH":
            md_box.label(text="Select a mesh", icon="ERROR")
        elif not props:
            md_box.label(text="Missing transfer props!", icon="ERROR")
        else:
            # 1) Source mesh
            md_box.prop(props, "mesh_source", text="Source Mesh")

            # 2) Search Method
            md_box.prop(props, "search_method", text="Search Method")

            # 3) Attribute to transfer
            md_box.prop(props, "attributes_to_transfer", text="Attribute")

            # 4) Optional toggles
            row = md_box.row(align=True)
            row.prop(
                props, "transfer_edit_selection", text="Edit-mode only", toggle=True
            )
            row.prop(
                props, "transfer_modified_source", text="Use Modifiers", toggle=True
            )

            # 5) Execute
            md_box.operator("object.transfer_mesh_data", text="Transfer", icon="EXPORT")

        layout.separator()
        layout.operator(
            "mesh.uv_flattened_copy", text="Create Mesh from UV", icon="MESH_GRID"
        )
        layout.label(text="Select faces in edit mode")

        # — BlendShape Randomizer —
        bs_box = layout.box()
        bs_box.label(text="BlendShape Randomizer", icon="SHAPEKEY_DATA")
        bs = context.scene.random_blendshape_props
        bs_box.prop(bs, "search_text")
        bs_box.prop(bs, "min_value")
        bs_box.prop(bs, "max_value")
        bs_box.operator("object.randomize_blendshapes")
        bs_box.operator("object.reset_blendshapes")

        # — Grid Generator —
        grid_box = layout.box()
        grid_box.label(text="Grid Generator", icon="MESH_GRID")
        g = context.scene.grid_settings
        grid_box.prop(g, "grid_rows")
        grid_box.prop(g, "grid_cols")
        grid_box.prop(g, "cell_size")
        grid_box.prop(g, "obj_type")
        grid_box.operator("object.create_grid")

        # — Mesh Name Sync —
        sync_box = layout.box()
        sync_box.label(text="Mesh Name Sync", icon="OUTLINER_OB_MESH")
        sync_box.operator("object.sync_mesh_names")

        # — Main Camera Switcher —
        cam_box = layout.box()
        cam_box.label(text="Main Camera Switcher", icon="CAMERA_DATA")
        cams = context.scene.camera_selector
        row = cam_box.row()
        row.template_list(
            "CAMERA_UL_List", "", cams, "camera_list", cams, "camera_index", rows=2
        )
        col = row.column(align=True)
        col.operator("camera_list.add", icon="ADD", text="")
        col.operator("camera_list.remove", icon="REMOVE", text="")
        if cams.camera_list:
            idx = cams.camera_index % len(cams.camera_list)
            op = cam_box.operator("camera_list.set_active", text="Set Active Camera")
            op.camera_name = cams.camera_list[idx].obj.name
        cam_box.operator("camera_list.previous", icon="TRIA_LEFT")
        cam_box.operator("camera_list.next", icon="TRIA_RIGHT")
        cam_box.label(text="💡 Ctrl+Shift←/→")

        # — Vertex Groups Batch Rename —
        vg_box = layout.box()
        vg_box.label(text="Vertex Groups Batch Rename", icon="GROUP_VERTEX")
        vg = context.scene.vg_tool_props
        vg_box.prop(vg, "prefix")
        vg_box.prop(vg, "replacement")
        vg_box.prop(vg, "replace_only_matched", toggle=True)
        vg_box.operator("object.process_vertex_groups")
