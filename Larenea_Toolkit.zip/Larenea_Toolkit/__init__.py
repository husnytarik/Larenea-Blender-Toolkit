bl_info = {
    "name": "Larenea Toolkit",
    "author": "Larenea",
    "version": (2, 5),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Larenea Toolkit; Properties > Data",
    "description": "All-in-one toolkit: BlendShape Transfer, Grid Generator, UV Projector, Mesh Name Sync, Main Camera Switcher, Mesh Data Transfer",
    "category": "3D View",
}

import bpy
import bmesh
import random
import string
from bpy.types import PropertyGroup
from bpy.props import (
    PointerProperty,
    StringProperty,
    FloatProperty,
    IntProperty,
    EnumProperty,
    BoolProperty,
    CollectionProperty,
)
from .operators import (
    MapTopology,
    TransferUVData,
    TransferMeshData,
    OBJECT_OT_transfer_uv_shape,
)
from .panel import VIEW3D_PT_th_tools


# --- Mesh Data Transfer Properties ---
def scene_chosenobject_poll(context, object):
    return object.type == "MESH"


def pick_armature(context, object):
    if context.active_object == object:
        return False
    return object.type == "ARMATURE"


def update_search_method(self, context):
    active = context.active_object
    if not active:
        return
    ob_prop = active.mesh_data_transfer_object
    if ob_prop.search_method == "UVS" and ob_prop.attributes_to_transfer == "UVS":
        ob_prop.search_method = "CLOSEST"


class MeshDataSettings(PropertyGroup):
    mesh_object_space: EnumProperty(
        items=[("WORLD", "World", "", 1), ("LOCAL", "Local", "", 2)],
        name="Object Space",
        default="LOCAL",
    )
    gp_object_space: EnumProperty(
        items=[("WORLD", "World", "", 1), ("LOCAL", "Local", "", 2)],
        name="Object Space",
        default="LOCAL",
    )
    search_method: EnumProperty(
        items=[
            ("CLOSEST", "Closest", "Closest Point on Surface", 1),
            ("RAYCAST", "Raycast", "Bidirectional Projection", 2),
            ("TOPOLOGY", "Topology", "Vertex ID/Topology", 3),
            ("UVS", "Active UV", "Active UV Search", 4),
        ],
        name="Search Method",
        default="UVS",
    )
    attributes_to_transfer: EnumProperty(
        items=[
            ("SHAPE", "Shape", "", 1),
            ("UVS", "UV set", "", 2),
            ("SHAPE_KEYS", "Shape Keys", "", 3),
            ("VERTEX_GROUPS", "Vertex Groups", "", 4),
        ],
        name="Attributes to transfer",
        default="SHAPE",
        update=update_search_method,
    )
    mesh_source: PointerProperty(
        name="Source mesh",
        type=bpy.types.Object,
        description="Pick a source mesh",
        poll=scene_chosenobject_poll,
    )
    arm_source: PointerProperty(
        name="Source armature",
        type=bpy.types.Object,
        description="Pick a source armature",
        poll=pick_armature,
    )
    arm_target: PointerProperty(
        name="Target armature",
        type=bpy.types.Object,
        description="Pick a target armature",
        poll=pick_armature,
    )
    vertex_group_filter: StringProperty(
        name="Vertex Group", description="Filter using vertex group"
    )
    invert_vertex_group_filter: BoolProperty(name="Invert vertex group")
    transfer_edit_selection: BoolProperty(
        name="Only edit mode selection", description="Restrict to edit selection"
    )
    transfer_shape_as_key: BoolProperty(
        name="Transfer as shape key", description="Store as shape key"
    )
    transfer_to_new_uv: BoolProperty()
    transfer_modified_source: BoolProperty(
        name="Transfer deformed source", description="Apply modifiers/shape keys"
    )
    exclude_muted_shapekeys: BoolProperty(
        name="Exclude muted", description="Do not transfer muted shape keys"
    )
    exclude_locked_groups: BoolProperty(
        name="Exclude locked", description="Do not transfer locked groups"
    )
    snap_to_closest_shape: BoolProperty(
        name="Snap to closest", description="Snap to nearest vertex"
    )
    snap_to_closest_shapekey: BoolProperty(
        name="Snap key to closest", description="Snap shape key"
    )


# --- Tools ---
class VertexGroupToolProperties(PropertyGroup):
    prefix: StringProperty(name="Find", default="")
    replacement: StringProperty(name="Replace", default="")
    replace_only_matched: BoolProperty(
        name="Only replace matched part",
        description="If enabled, only the matched prefix part is replaced (e.g. mixamorig:hips -> testhips).",
        default=True,
    )


class OBJECT_OT_process_vertex_groups(bpy.types.Operator):
    bl_idname = "object.process_vertex_groups"
    bl_label = "🔁 Replace"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.vg_tool_props
        obj = context.object
        if not obj or obj.type != "MESH":
            self.report({"WARNING"}, "Select mesh")
            return {"CANCELLED"}
        for vg in list(obj.vertex_groups):
            if vg.name.startswith(props.prefix):
                if not props.replacement.strip():
                    if props.replace_only_matched:
                        # Sadece eşleşen kısmı kaldır
                        new_name = vg.name.replace(props.prefix, "", 1)
                        # Eğer isim tamamen boş kaldıysa o zaman sil
                        if not new_name.strip():
                            obj.vertex_groups.remove(vg)
                        else:
                            vg.name = new_name
                    else:
                        # Full rename modunda Replace boşsa isim boş olacağı için group'u sil
                        obj.vertex_groups.remove(vg)
                else:
                    if props.replace_only_matched:
                        vg.name = vg.name.replace(props.prefix, props.replacement, 1)
                    else:
                        vg.name = props.replacement
        return {"FINISHED"}


class RandomBlendShapeProperties(PropertyGroup):
    search_text: StringProperty(name="Prefix", default="")
    min_value: FloatProperty(name="Min", default=0.0)
    max_value: FloatProperty(name="Max", default=1.0)


class OBJECT_OT_randomize_blendshapes(bpy.types.Operator):
    bl_idname = "object.randomize_blendshapes"
    bl_label = "🔀 Randomize BlendShapes"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.random_blendshape_props
        selected = [o for o in context.selected_objects if o.data.shape_keys]
        ref = context.active_object
        if not selected or not ref or not ref.data.shape_keys:
            self.report({"WARNING"}, "Select shape key objs")
            return {"CANCELLED"}
        matched = [
            kb.name
            for kb in ref.data.shape_keys.key_blocks
            if kb.name.startswith(props.search_text)
        ]
        if not matched:
            self.report({"INFO"}, "No matches")
            return {"CANCELLED"}
        rand_vals = {
            n: random.uniform(props.min_value, props.max_value) for n in matched
        }
        for o in selected:
            for n, v in rand_vals.items():
                if n in o.data.shape_keys.key_blocks:
                    o.data.shape_keys.key_blocks[n].value = v
        self.report({"INFO"}, f"{len(rand_vals)} keys randomized")
        return {"FINISHED"}


class OBJECT_OT_reset_blendshapes(bpy.types.Operator):
    bl_idname = "object.reset_blendshapes"
    bl_label = "↩️ Reset BlendShapes"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.random_blendshape_props
        ref = context.active_object
        sel = [o for o in context.selected_objects if o.data.shape_keys]
        if not ref or not sel:
            self.report({"WARNING"}, "Select shape key objs")
            return {"CANCELLED"}
        keys = [
            k.name
            for k in ref.data.shape_keys.key_blocks
            if k.name.startswith(props.search_text)
        ]
        for o in sel:
            for k in keys:
                if k in o.data.shape_keys.key_blocks:
                    o.data.shape_keys.key_blocks[k].value = 0.0
        self.report({"INFO"}, f"{len(keys)} reset")
        return {"FINISHED"}


class OBJECT_OT_sync_mesh_names(bpy.types.Operator):
    bl_idname = "object.sync_mesh_names"
    bl_label = "🔗 Sync Mesh Names"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        for o in context.selected_objects:
            if o.type == "MESH":
                o.data.name = o.name
        self.report({"INFO"}, "Mesh names synced")
        return {"FINISHED"}


class GridSettings(PropertyGroup):
    grid_rows: IntProperty(name="Rows", default=4, min=1)
    grid_cols: IntProperty(name="Columns", default=4, min=1)
    cell_size: FloatProperty(name="Size", default=2.0, min=0.1)
    obj_type: EnumProperty(
        name="Primitive",
        items=[
            ("PLANE", "Plane", ""),
            ("CUBE", "Cube", ""),
            ("UV_SPHERE", "Sphere", ""),
            ("CYLINDER", "Cylinder", ""),
        ],
        default="PLANE",
    )


class OBJECT_OT_create_grid(bpy.types.Operator):
    bl_idname = "object.create_grid"
    bl_label = "🧱 Create Grid"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.grid_settings
        bpy.ops.object.select_all(action="SELECT")
        bpy.ops.object.delete(use_global=False)
        for y in range(s.grid_rows):
            for x in range(s.grid_cols):
                loc = (x * s.cell_size, -y * s.cell_size, 0)
                name = f"{chr(65+y)}{x+1:02}"
                if s.obj_type == "PLANE":
                    bpy.ops.mesh.primitive_plane_add(size=s.cell_size, location=loc)
                elif s.obj_type == "CUBE":
                    bpy.ops.mesh.primitive_cube_add(size=s.cell_size, location=loc)
                elif s.obj_type == "UV_SPHERE":
                    bpy.ops.mesh.primitive_uv_sphere_add(
                        radius=s.cell_size / 2, location=loc
                    )
                elif s.obj_type == "CYLINDER":
                    bpy.ops.mesh.primitive_cylinder_add(
                        radius=s.cell_size / 2, depth=s.cell_size, location=loc
                    )
                obj = bpy.context.active_object
                obj.name = name
                obj.data.name = name
        return {"FINISHED"}


class MESH_OT_uv_flattened_copy(bpy.types.Operator):
    bl_idname = "mesh.uv_flattened_copy"
    bl_label = "📐 UV'den Yeni Obje"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        # only in edit‐mesh mode on a mesh
        obj = context.object
        return obj and obj.type == "MESH" and context.mode == "EDIT_MESH"

    def execute(self, context):
        obj = context.object
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active
        if not uv_layer:
            self.report({"ERROR"}, "No UV")
            return {"CANCELLED"}

        verts, faces, vmap = [], [], {}
        for face in bm.faces:
            if not any(v.select for v in face.verts):
                continue
            idxs = []
            for loop in face.loops:
                v = loop.vert
                if not v.select:
                    continue
                if v not in vmap:
                    uv = loop[uv_layer].uv
                    verts.append((uv.x, uv.y, 0))
                    vmap[v] = len(verts) - 1
                idxs.append(vmap[v])
            if len(idxs) >= 3:
                faces.append(idxs)

        new_mesh = bpy.data.meshes.new(obj.name + "_UVCopy")
        new_mesh.from_pydata(verts, [], faces)
        new_obj = bpy.data.objects.new(obj.name + "_UVFlat", new_mesh)
        context.collection.objects.link(new_obj)

        self.report({"INFO"}, "UV copy done")
        return {"FINISHED"}


def uv_flatten_menu(self, context):
    self.layout.operator(
        MESH_OT_uv_flattened_copy.bl_idname,
        text=MESH_OT_uv_flattened_copy.bl_label,
        icon="MESH_GRID",
    )


class CameraListItem(PropertyGroup):
    obj: PointerProperty(type=bpy.types.Object)


class CAMERA_UL_List(bpy.types.UIList):
    def draw_item(
        self, context, layout, data, item, icon, active_data, active_propname, index
    ):
        if item.obj:
            layout.prop(item.obj, "name", text="", emboss=False, icon="CAMERA_DATA")
        else:
            layout.label(text="None", icon="ERROR")


class CameraSelectorProperties(PropertyGroup):
    camera_list: CollectionProperty(type=CameraListItem)
    camera_index: IntProperty()


class CAMERA_OT_Add(bpy.types.Operator):
    bl_idname = "camera_list.add"
    bl_label = "Add Camera"

    def execute(self, context):
        props = context.scene.camera_selector
        new = props.camera_list.add()
        if context.active_object and context.active_object.type == "CAMERA":
            new.obj = context.active_object
        else:
            self.report({"WARNING"}, "Select camera")
        return {"FINISHED"}


class CAMERA_OT_Remove(bpy.types.Operator):
    bl_idname = "camera_list.remove"
    bl_label = "Remove Camera"

    def execute(self, context):
        props = context.scene.camera_selector
        if props.camera_index < len(props.camera_list):
            props.camera_list.remove(props.camera_index)
        return {"FINISHED"}


class CAMERA_OT_SetActive(bpy.types.Operator):
    bl_idname = "camera_list.set_active"
    bl_label = "Set Active Camera"
    camera_name: StringProperty()

    def execute(self, context):
        cam = bpy.data.objects.get(self.camera_name)
        if cam and cam.type == "CAMERA":
            context.scene.camera = cam
            return {"FINISHED"}
        self.report({"WARNING"}, "Invalid camera")
        return {"CANCELLED"}


class CAMERA_OT_Next(bpy.types.Operator):
    bl_idname = "camera_list.next"
    bl_label = "Next Camera"

    def execute(self, context):
        props = context.scene.camera_selector
        if not props.camera_list:
            self.report({"WARNING"}, "No cameras")
            return {"CANCELLED"}
        props.camera_index = (props.camera_index + 1) % len(props.camera_list)
        cam = props.camera_list[props.camera_index].obj
        if cam:
            context.scene.camera = cam
        return {"FINISHED"}


class CAMERA_OT_Previous(bpy.types.Operator):
    bl_idname = "camera_list.previous"
    bl_label = "Previous Camera"

    def execute(self, context):
        props = context.scene.camera_selector
        if not props.camera_list:
            self.report({"WARNING"}, "No cameras")
            return {"CANCELLED"}
        props.camera_index = (props.camera_index - 1) % len(props.camera_list)
        cam = props.camera_list[props.camera_index].obj
        if cam:
            context.scene.camera = cam
        return {"FINISHED"}


addon_keymaps = []


def register_keymaps():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name="3D View", space_type="VIEW_3D")
        kmi1 = km.keymap_items.new(
            "camera_list.next", "RIGHT_ARROW", "PRESS", ctrl=True, shift=True
        )
        kmi2 = km.keymap_items.new(
            "camera_list.previous", "LEFT_ARROW", "PRESS", ctrl=True, shift=True
        )
        addon_keymaps.extend([(km, kmi1), (km, kmi2)])


def unregister_keymaps():
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()


classes = (
    MeshDataSettings,
    MapTopology,
    TransferUVData,
    TransferMeshData,
    OBJECT_OT_transfer_uv_shape,
    VertexGroupToolProperties,
    OBJECT_OT_process_vertex_groups,
    RandomBlendShapeProperties,
    OBJECT_OT_randomize_blendshapes,
    OBJECT_OT_reset_blendshapes,
    OBJECT_OT_sync_mesh_names,
    GridSettings,
    OBJECT_OT_create_grid,
    CameraListItem,
    CAMERA_UL_List,
    CameraSelectorProperties,
    CAMERA_OT_Add,
    CAMERA_OT_Remove,
    CAMERA_OT_SetActive,
    CAMERA_OT_Next,
    CAMERA_OT_Previous,
    MESH_OT_uv_flattened_copy,
    VIEW3D_PT_th_tools,
)


def register():
    # 1) Register all classes
    for cls in classes:
        bpy.utils.register_class(cls)

    # 2) Attach PointerProperties
    bpy.types.Object.mesh_data_transfer_object = PointerProperty(type=MeshDataSettings)
    bpy.types.Scene.vg_tool_props = PointerProperty(type=VertexGroupToolProperties)
    bpy.types.Scene.random_blendshape_props = PointerProperty(
        type=RandomBlendShapeProperties
    )
    bpy.types.Scene.grid_settings = PointerProperty(type=GridSettings)
    bpy.types.Scene.camera_selector = PointerProperty(type=CameraSelectorProperties)

    # 3) Register any keymaps you have
    register_keymaps()


def unregister():
    # 1) Unregister keymaps first
    unregister_keymaps()

    # 2) Remove PointerProperties
    del bpy.types.Scene.camera_selector
    del bpy.types.Scene.grid_settings
    del bpy.types.Scene.random_blendshape_props
    del bpy.types.Scene.vg_tool_props
    del bpy.types.Object.mesh_data_transfer_object

    # 3) Unregister all classes in reverse order
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
