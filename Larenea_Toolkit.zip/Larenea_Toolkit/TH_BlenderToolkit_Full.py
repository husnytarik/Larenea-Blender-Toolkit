bl_info = {
    "name": "Larenea Toolkit",
    "author": "Larenea",
    "version": (2, 5),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Larenea Toolkit",
    "description": "All-in-one toolkit: BlendShape Transfer, Grid Generator, UV Projector, Mesh Name Sync, Main Camera Switcher",
    "category": "3D View",
}

import bpy
import bmesh
import random
import string
from .operators import TransferUVData


class TransferUVData(bpy.types.Operator):
    """Aktif UV’den source objeye veri aktarımı yapar"""

    bl_idname = "object.transfer_uv_data"
    bl_label = "UV → Mesh Transfer"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        props = getattr(obj, "mesh_data_transfer_object", None)
        return obj and obj.type == "MESH" and props and props.mesh_source is not None

    def execute(self, context):
        obj = context.active_object
        props = obj.mesh_data_transfer_object
        transfer = MeshDataTransfer(
            target=obj,
            source=props.mesh_source,
            uv_space=True,
            # diğer parametreleri props üzerinden aktarabilirsiniz
        )
        transfer.transfer_uvs()
        transfer.free()
        self.report({"INFO"}, "UV verisi aktarıldı.")
        return {"FINISHED"}


# 🔧 Yeni: Vertex Group Sil/Değiştir Özellikleri
class VertexGroupToolProperties(bpy.types.PropertyGroup):
    prefix: bpy.props.StringProperty(name="Find", default="")
    replacement: bpy.props.StringProperty(name="Replace", default="")


class OBJECT_OT_process_vertex_groups(bpy.types.Operator):
    bl_idname = "object.process_vertex_groups"
    bl_label = "🔁 Replace"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.vg_tool_props
        prefix = props.prefix
        replacement = props.replacement

        obj = context.object
        if not obj or obj.type != "MESH":
            self.report({"WARNING"}, "Bir mesh objesi seçili olmalı")
            return {"CANCELLED"}

        for vg in list(obj.vertex_groups):
            if vg.name.startswith(prefix):
                if replacement.strip() == "":
                    obj.vertex_groups.remove(vg)
                else:
                    new_name = vg.name.replace(prefix, replacement, 1)
                    vg.name = new_name
        return {"FINISHED"}


class RandomBlendShapeProperties(bpy.types.PropertyGroup):
    search_text: bpy.props.StringProperty(name="Prefix", default="")
    min_value: bpy.props.FloatProperty(name="Min", default=0.0)
    max_value: bpy.props.FloatProperty(name="Max", default=1.0)


### 🎭 BlendShape Tools
class OBJECT_OT_randomize_blendshapes(bpy.types.Operator):
    bl_idname = "object.randomize_blendshapes"
    bl_label = "🔀 Randomize BlendShapes"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.random_blendshape_props
        selected_objects = [o for o in context.selected_objects if o.data.shape_keys]
        ref_obj = context.active_object

        if not selected_objects or not ref_obj or not ref_obj.data.shape_keys:
            self.report({"WARNING"}, "Geçerli shape key objeleri seçin.")
            return {"CANCELLED"}

        key_blocks = ref_obj.data.shape_keys.key_blocks
        matched_keys = [
            kb.name for kb in key_blocks if kb.name.startswith(props.search_text)
        ]

        if not matched_keys:
            self.report({"INFO"}, "Eşleşen blendshape bulunamadı.")
            return {"CANCELLED"}

        # Her isim için bir değer üret
        random_values = {
            name: random.uniform(props.min_value, props.max_value)
            for name in matched_keys
        }

        for obj in selected_objects:
            if not obj.data.shape_keys:
                continue
            for name in matched_keys:
                if name in obj.data.shape_keys.key_blocks:
                    obj.data.shape_keys.key_blocks[name].value = random_values[name]

        self.report({"INFO"}, f"{len(random_values)} shape key rastgele değer aldı.")
        return {"FINISHED"}


class OBJECT_OT_reset_blendshapes(bpy.types.Operator):
    bl_idname = "object.reset_blendshapes"
    bl_label = "↩️ Reset BlendShapes"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        props = context.scene.random_blendshape_props
        selected = [o for o in context.selected_objects if o.data.shape_keys]
        ref = context.active_object
        if not ref or not selected:
            self.report({"WARNING"}, "Select shape key objects.")
            return {"CANCELLED"}
        keys = [
            k.name
            for k in ref.data.shape_keys.key_blocks
            if k.name.startswith(props.search_text)
        ]
        for obj in selected:
            for k in keys:
                if k in obj.data.shape_keys.key_blocks:
                    obj.data.shape_keys.key_blocks[k].value = 0.0
        self.report({"INFO"}, f"{len(keys)} keys reset.")
        return {"FINISHED"}


### 🔗 Mesh Name Sync
class OBJECT_OT_sync_mesh_names(bpy.types.Operator):
    bl_idname = "object.sync_mesh_names"
    bl_label = "🔗 Sync Mesh Names"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        for obj in context.selected_objects:
            if obj.type == "MESH":
                obj.data.name = obj.name
        self.report({"INFO"}, "Mesh names synced.")
        return {"FINISHED"}


### 🔲 Grid Creator
class GridSettings(bpy.types.PropertyGroup):
    grid_rows: bpy.props.IntProperty(name="Rows", default=4, min=1)
    grid_cols: bpy.props.IntProperty(name="Columns", default=4, min=1)
    cell_size: bpy.props.FloatProperty(name="Size", default=2.0, min=0.1)
    obj_type: bpy.props.EnumProperty(
        name="Primitive",
        items=[
            ("PLANE", "Plane", ""),
            ("CUBE", "Cube", ""),
            ("UV_SPHERE", "Sphere", ""),
            ("CYLINDER", "Cylinder", ""),
        ],
        default="PLANE",
    )


class OBJECT_OT_create_grid(bpy.types.Operator):
    bl_idname = "object.create_grid"
    bl_label = "🧱 Create Grid"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = context.scene.grid_settings
        bpy.ops.object.select_all(action="SELECT")
        bpy.ops.object.delete(use_global=False)
        for y in range(s.grid_rows):
            for x in range(s.grid_cols):
                loc = (x * s.cell_size, -y * s.cell_size, 0)
                name = f"{chr(65 + y)}{x+1:02}"
                if s.obj_type == "PLANE":
                    bpy.ops.mesh.primitive_plane_add(size=s.cell_size, location=loc)
                elif s.obj_type == "CUBE":
                    bpy.ops.mesh.primitive_cube_add(size=s.cell_size, location=loc)
                elif s.obj_type == "UV_SPHERE":
                    bpy.ops.mesh.primitive_uv_sphere_add(
                        radius=s.cell_size / 2, location=loc
                    )
                elif s.obj_type == "CYLINDER":
                    bpy.ops.mesh.primitive_cylinder_add(
                        radius=s.cell_size / 2, depth=s.cell_size, location=loc
                    )
                obj = bpy.context.active_object
                obj.name = name
                obj.data.name = name
        return {"FINISHED"}


### 📐 UV Flattened Copy (Right-click menu)
class MESH_OT_uv_flattened_copy(bpy.types.Operator):
    bl_idname = "mesh.uv_flattened_copy"
    bl_label = "📐 UV'den Yeni Obje"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.object
        if not obj or obj.type != "MESH" or context.mode != "EDIT_MESH":
            self.report({"ERROR"}, "Edit modda mesh seçili olmalı.")
            return {"CANCELLED"}
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.active
        if not uv_layer:
            self.report({"ERROR"}, "UV layer yok.")
            return {"CANCELLED"}
        verts, faces, vmap = [], [], {}
        for face in bm.faces:
            if not any(v.select for v in face.verts):
                continue
            idxs = []
            for loop in face.loops:
                v = loop.vert
                if not v.select:
                    continue
                if v not in vmap:
                    uv = loop[uv_layer].uv
                    verts.append((uv.x, uv.y, 0))
                    vmap[v] = len(verts) - 1
                idxs.append(vmap[v])
            if len(idxs) >= 3:
                faces.append(idxs)
        new_mesh = bpy.data.meshes.new(obj.name + "_UVCopy")
        new_mesh.from_pydata(verts, [], faces)
        new_obj = bpy.data.objects.new(obj.name + "_UVFlat", new_mesh)
        context.collection.objects.link(new_obj)
        self.report({"INFO"}, "Yeni obje oluşturuldu.")
        return {"FINISHED"}


def menu_func(self, context):
    self.layout.operator(MESH_OT_uv_flattened_copy.bl_idname, icon="MESH_GRID")


### 🎥 Kamera Listesi ve Geçiş
class CameraListItem(bpy.types.PropertyGroup):
    obj: bpy.props.PointerProperty(type=bpy.types.Object)


class CAMERA_UL_List(bpy.types.UIList):
    def draw_item(
        self, context, layout, data, item, icon, active_data, active_propname, index
    ):
        if item.obj:
            layout.prop(item.obj, "name", text="", emboss=False, icon="CAMERA_DATA")
        else:
            layout.label(text="None", icon="ERROR")


class CameraSelectorProperties(bpy.types.PropertyGroup):
    camera_list: bpy.props.CollectionProperty(type=CameraListItem)
    camera_index: bpy.props.IntProperty()


class CAMERA_OT_Add(bpy.types.Operator):
    bl_idname = "camera_list.add"
    bl_label = "Add Camera"

    def execute(self, context):
        props = context.scene.camera_selector
        new_item = props.camera_list.add()
        if context.active_object and context.active_object.type == "CAMERA":
            new_item.obj = context.active_object
        else:
            self.report({"WARNING"}, "Select a camera first.")
        return {"FINISHED"}


class CAMERA_OT_Remove(bpy.types.Operator):
    bl_idname = "camera_list.remove"
    bl_label = "Remove Camera"

    def execute(self, context):
        props = context.scene.camera_selector
        if props.camera_index < len(props.camera_list):
            props.camera_list.remove(props.camera_index)
        return {"FINISHED"}


class CAMERA_OT_SetActive(bpy.types.Operator):
    bl_idname = "camera_list.set_active"
    bl_label = "Set Active Camera"
    camera_name: bpy.props.StringProperty()

    def execute(self, context):
        cam = bpy.data.objects.get(self.camera_name)
        if cam and cam.type == "CAMERA":
            context.scene.camera = cam
            return {"FINISHED"}
        else:
            self.report({"WARNING"}, "Camera not found or invalid.")
            return {"CANCELLED"}


class CAMERA_OT_Next(bpy.types.Operator):
    bl_idname = "camera_list.next"
    bl_label = "Next Camera"

    def execute(self, context):
        props = context.scene.camera_selector
        if not props.camera_list:
            self.report({"WARNING"}, "No cameras in the list.")
            return {"CANCELLED"}
        props.camera_index = (props.camera_index + 1) % len(props.camera_list)
        cam = props.camera_list[props.camera_index].obj
        if cam:
            context.scene.camera = cam
        return {"FINISHED"}


class CAMERA_OT_Previous(bpy.types.Operator):
    bl_idname = "camera_list.previous"
    bl_label = "Previous Camera"

    def execute(self, context):
        props = context.scene.camera_selector
        if not props.camera_list:
            self.report({"WARNING"}, "No cameras in the list.")
            return {"CANCELLED"}
        props.camera_index = (props.camera_index - 1) % len(props.camera_list)
        cam = props.camera_list[props.camera_index].obj
        if cam:
            context.scene.camera = cam
        return {"FINISHED"}


### 🧰 UI Panel
class VIEW3D_PT_th_tools(bpy.types.Panel):
    bl_label = "🛠️ Larenea Toolkit"
    bl_idname = "VIEW3D_PT_th_blender_toolkit"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Larenea Toolkit"

    def draw(self, context):
        layout = self.layout
        props = context.scene.random_blendshape_props
        g = context.scene.grid_settings
        cams = context.scene.camera_selector

        layout.separator()
        layout.label(text="UV → Mesh Transfer", icon="GROUP_UVS")
        # Eğer bir kaynak seçim prop’unuz varsa:
        uv_props = context.active_object.mesh_data_transfer_object
        layout.prop(uv_props, "mesh_source", text="Source Mesh")
        layout.operator(
            "object.transfer_uv_data", text="Transfer UV Data", icon="ARROWS"
        )

        layout.label(text="	BlendShape Randomizer", icon="SHAPEKEY_DATA")
        layout.prop(props, "search_text")
        layout.prop(props, "min_value")
        layout.prop(props, "max_value")
        layout.operator("object.randomize_blendshapes")
        layout.operator("object.reset_blendshapes")

        layout.separator()
        layout.label(text="Grid Generator", icon="MESH_GRID")
        layout.prop(g, "grid_rows")
        layout.prop(g, "grid_cols")
        layout.prop(g, "cell_size")
        layout.prop(g, "obj_type")
        layout.operator("object.create_grid")

        layout.separator()
        layout.label(text="Mesh Name Sync", icon="OUTLINER_OB_MESH")
        layout.operator("object.sync_mesh_names")

        layout.separator()
        layout.label(text="Main Camera Switcher", icon="CAMERA_DATA")
        row = layout.row()
        row.template_list(
            "CAMERA_UL_List", "", cams, "camera_list", cams, "camera_index", rows=2
        )
        col = row.column(align=True)
        col.operator("camera_list.add", icon="ADD", text="")
        col.operator("camera_list.remove", icon="REMOVE", text="")

        if cams.camera_list and cams.camera_index < len(cams.camera_list):
            cam = cams.camera_list[cams.camera_index].obj
            if cam:
                layout.operator(
                    "camera_list.set_active", text="Set Active Camera"
                ).camera_name = cam.name

        layout.operator("camera_list.previous", icon="TRIA_LEFT")
        layout.operator("camera_list.next", icon="TRIA_RIGHT")
        layout.label(text="💡 Kısayol ile geçiş: Ctrl + Shift + ← / →")

        # 🎯 Vertex Group Aracı
        layout.separator()
        layout.label(text="Vertex Groups Batch Rename", icon="GROUP_VERTEX")
        vg_props = context.scene.vg_tool_props
        layout.prop(vg_props, "prefix")
        layout.prop(vg_props, "replacement")
        layout.operator("object.process_vertex_groups")


### ⌨️ Kısayollar
addon_keymaps = []


def register_keymaps():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name="3D View", space_type="VIEW_3D")
        kmi1 = km.keymap_items.new(
            CAMERA_OT_Next.bl_idname, "RIGHT_ARROW", "PRESS", ctrl=True, shift=True
        )
        kmi2 = km.keymap_items.new(
            CAMERA_OT_Previous.bl_idname, "LEFT_ARROW", "PRESS", ctrl=True, shift=True
        )
        addon_keymaps.extend([(km, kmi1), (km, kmi2)])


def unregister_keymaps():
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()


### 🔁 Kayıt / Kaldırma
classes = (
    RandomBlendShapeProperties,
    OBJECT_OT_randomize_blendshapes,
    OBJECT_OT_reset_blendshapes,
    OBJECT_OT_sync_mesh_names,
    GridSettings,
    OBJECT_OT_create_grid,
    MESH_OT_uv_flattened_copy,
    CameraListItem,
    CAMERA_UL_List,
    CameraSelectorProperties,
    CAMERA_OT_Add,
    CAMERA_OT_Remove,
    CAMERA_OT_SetActive,
    CAMERA_OT_Next,
    CAMERA_OT_Previous,
    VIEW3D_PT_th_tools,
    VertexGroupToolProperties,
    OBJECT_OT_process_vertex_groups,
    TransferUVData,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Object.mesh_data_transfer_object = bpy.props.PointerProperty(
        type=MeshDataTransferProperties
    )
    bpy.types.Scene.vg_tool_props = bpy.props.PointerProperty(
        type=VertexGroupToolProperties
    )
    bpy.types.Scene.random_blendshape_props = bpy.props.PointerProperty(
        type=RandomBlendShapeProperties
    )
    bpy.types.Scene.grid_settings = bpy.props.PointerProperty(type=GridSettings)
    bpy.types.Scene.camera_selector = bpy.props.PointerProperty(
        type=CameraSelectorProperties
    )
    bpy.types.VIEW3D_MT_edit_mesh_context_menu.append(menu_func)
    register_keymaps()


def unregister():
    bpy.types.VIEW3D_MT_edit_mesh_context_menu.remove(menu_func)
    unregister_keymaps()
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.vg_tool_props
    del bpy.types.Scene.random_blendshape_props
    del bpy.types.Scene.grid_settings
    del bpy.types.Scene.camera_selector


if __name__ == "__main__":
    register()
